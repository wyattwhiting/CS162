Name: Wyatt Whiting
Desc: The program has all the required function, but many go unused since they aren't required for the program functionality. I tested them before implementing the user interface, so feel free to test them out and verify they work. I didn't do any of the extra credit. I also modified the required function names from function_name to functionName since I prefer camel case, but the prototypes are still the same as required on the assignment. 

